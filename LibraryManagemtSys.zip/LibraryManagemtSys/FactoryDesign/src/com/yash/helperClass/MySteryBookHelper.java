package com.yash.helperClass;

import java.util.List;

import com.yash.ifactory.iBookCategory;
import com.yash.library.model.Book;

public class MySteryBookHelper implements iBookCategory {

	@Override
	public Book getBookNames(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
