package com.yash.ifactory;

import java.util.List;

import com.yash.library.model.Book;

public interface iBookCategory {
	Book getBookNames(int id);
}
